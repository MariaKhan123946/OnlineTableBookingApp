import "package:firebase_auth/firebase_auth.dart";
import "package:flutter/material.dart";
import "package:ui/constant/space_values.dart";
import "package:ui/Authentication/signin.dart";

class Signup_screen extends StatefulWidget {
  const Signup_screen({super.key});

  @override
  State<Signup_screen> createState() => _Signup_screenState();
}

class _Signup_screenState extends State<Signup_screen> {
  TextEditingController Emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  TextEditingController cpasswordcontroller = TextEditingController();
  void CreateAccount() async {
    String Email = Emailcontroller.text.trim();
    String password = passwordcontroller.text.trim();
    String cpassword = cpasswordcontroller.text.trim();
    if (Email == "" || password == "" || cpassword == "") {
      print("please fill all fields");
    } else if (password != cpassword) {
      print("fields does'nt match");
    } else {
      try {
        UserCredential userCredential = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: Email, password: password);
        if (userCredential.user != null) {
          Navigator.pop(context);
        }
      } on FirebaseAuthException catch (ex) {
        print(ex.code.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Spaces.y10,
          const Center(
            child: Image(
              image: AssetImage("assets/profile.png"),
              width: 100,
              height: 100,
            ),
          ),
          Spaces.y6,
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: TextFormField(
              controller: Emailcontroller,
              decoration: InputDecoration(
                hintText: "Email",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: TextFormField(
              controller: passwordcontroller,
              decoration: InputDecoration(
                hintText: "Password",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: TextFormField(
              controller: cpasswordcontroller,
              decoration: InputDecoration(
                hintText: "confirm password ",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
          ),
          Spaces.y3,
          ElevatedButton(
              onPressed: () {
                CreateAccount();
              },
              child: const Text("Signup")),
          TextButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Login_screen()));
              },
              child: const Text("Login"))
        ],
      ),
    ));
  }
}
