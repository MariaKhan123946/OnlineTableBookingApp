import "package:firebase_auth/firebase_auth.dart";
import "package:flutter/material.dart";
import "package:ui/constant/space_values.dart";
import "package:ui/home.dart";

class Login_screen extends StatefulWidget {
  const Login_screen({super.key});

  @override
  State<Login_screen> createState() => _Login_screenState();
}

class _Login_screenState extends State<Login_screen> {
  TextEditingController Emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  void Login() async {
    String Email = Emailcontroller.text.trim();
    String password = passwordcontroller.text.trim();
    if (Email == "" || password == "") {
      print("fill all the fields");
    } else {
      try {
        UserCredential userCredential = await FirebaseAuth.instance
            .signInWithEmailAndPassword(email: Email, password: password);
        if (userCredential.user != null) {
          Navigator.popUntil(context, (route) => route.isFirst);
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => HomeScreen(),
              ));
        }
      } on FirebaseAuthException catch (ex) {
        print(ex.code.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Spaces.y10,
          Center(
            child: Image(
              image: AssetImage("assets/profile.png"),
              width: 100,
              height: 100,
            ),
          ),
          Spaces.y6,
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: TextFormField(
              controller: Emailcontroller,
              decoration: InputDecoration(
                hintText: "Email",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: TextFormField(
              controller: passwordcontroller,
              decoration: InputDecoration(
                hintText: "Password",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
          ),
          Spaces.y3,
          ElevatedButton(
              onPressed: () {
                Login();
              },
              child: Text("Login")),
        ],
      ),
    ));
  }
}
