import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:ui/Authentication/firebase_options.dart';
import 'package:ui/home.dart';
import 'package:ui/Authentication/signin.dart';
import 'package:ui/Authentication/signup.dart';
import 'package:ui/tablebooking.dart';
import 'package:ui/view/Booking_details.dart';
import 'package:ui/view/onboarding1.dart';
import 'package:ui/view/onboarding2.dart';
import 'package:ui/view/onboarding3.dart';
import 'package:ui/view/onboardingcontroller.dart';
import 'package:ui/view/profile.dart';
import 'package:ui/view/reservation_details.dart';

import 'deals.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return Sizer(
      builder: (BuildContext context, Orientation orientation,
          DeviceType deviceType) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: ThemeData.fallback(),
          home: Profile(),
          // home: (FirebaseAuth.instance.currentUser != null)
          //     ? HomeScreen()
          //     : Login_screen(),
        );
      },
    );
  }
}
